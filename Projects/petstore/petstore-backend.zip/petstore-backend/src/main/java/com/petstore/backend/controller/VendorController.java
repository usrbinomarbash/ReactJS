package com.petstore.backend.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import com.petstore.backend.model.Vendor;
import com.petstore.backend.repository.VendorRepository;

@RestController
@RequestMapping("/api/vendors")
@CrossOrigin(origins = "http://localhost:3000")
public class VendorController {

    @Autowired
    private VendorRepository vendorRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // GET all vendors
    @GetMapping
    public List<Vendor> getAllVendors() {
        System.out.println("GET /api/vendors called");
        return vendorRepository.findAll();
    }

    // GET vendor by ID
    @GetMapping("/{id}")
    public ResponseEntity<Vendor> getVendorById(@PathVariable Long id) {
        System.out.println("GET /api/vendors/" + id + " called");
        return vendorRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET vendor with product count
    @GetMapping("/{id}/products")
    public Map<String, Object> getVendorWithProducts(@PathVariable Long id) {
        System.out.println("GET /api/vendors/" + id + "/products called");
        
        Map<String, Object> vendor = jdbcTemplate.queryForMap(
            "SELECT * FROM vendor WHERE vendor_id = ?", id
        );

        List<Map<String, Object>> products = jdbcTemplate.queryForList(
            "SELECT * FROM product WHERE vendor_id = ?", id
        );

        vendor.put("products", products);
        vendor.put("product_count", products.size());
        return vendor;
    }

    // GET vendor summary (all vendors with product counts)
    @GetMapping("/summary")
    public List<Map<String, Object>> getVendorSummary() {
        System.out.println("GET /api/vendors/summary called");
        return jdbcTemplate.queryForList("""
            SELECT v.*,
                   COUNT(p.product_id) as product_count,
                   COALESCE(SUM(p.stock_quantity), 0) as total_stock,
                   COALESCE(SUM(p.stock_quantity * p.price), 0) as inventory_value
            FROM vendor v
            LEFT JOIN product p ON v.vendor_id = p.vendor_id
            GROUP BY v.vendor_id
            ORDER BY product_count DESC
            """);
    }

    // POST create vendor
    @PostMapping
    public ResponseEntity<Vendor> createVendor(@RequestBody Vendor vendor) {
        System.out.println("POST /api/vendors called");
        Vendor saved = vendorRepository.save(vendor);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT update vendor
    @PutMapping("/{id}")
    public ResponseEntity<Vendor> updateVendor(@PathVariable Long id, @RequestBody Vendor vendorDetails) {
        System.out.println("PUT /api/vendors/" + id + " called");
        return vendorRepository.findById(id)
                .map(existing -> {
                    existing.setName(vendorDetails.getName());
                    existing.setContact_person(vendorDetails.getContact_person());
                    existing.setEmail(vendorDetails.getEmail());
                    existing.setName(vendorDetails.getName());
                    existing.setAddress(vendorDetails.getClass());
                    return ResponseEntity.ok(vendorRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE vendor
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVendor(@PathVariable Long id) {
        System.out.println("DELETE /api/vendors/" + id + " called");
        if (vendorRepository.existsById(id)) {
            vendorRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}