package com.petstore.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "http://localhost:3000")
public class ReportController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Dashboard summary statistics
    @GetMapping("/dashboard-stats")
    public Map<String, Object> getDashboardStats() {
        System.out.println("GET /api/reports/dashboard-stats called");
        
        String sql = """
            SELECT
                (SELECT COUNT(*) FROM customer) as total_customers,
                (SELECT COUNT(*) FROM pet) as total_pets,
                (SELECT COUNT(*) FROM product) as total_products,
                (SELECT COUNT(*) FROM booking) as total_bookings,
                (SELECT COUNT(*) FROM orders) as total_orders,
                (SELECT COALESCE(SUM(total_amount), 0) FROM orders) as total_revenue,
                (SELECT COUNT(*) FROM product WHERE stock_quantity < 10) as low_stock_count,
                (SELECT ROUND(AVG(pet_count), 2) FROM (
                    SELECT COUNT(pet_id) as pet_count FROM pet GROUP BY customer_id
                ) as pet_counts) as avg_pets_per_customer
            """;
        return jdbcTemplate.queryForMap(sql);
    }

    // Top selling products
    @GetMapping("/top-products")
    public List<Map<String, Object>> getTopSellingProducts() {
        System.out.println("GET /api/reports/top-products called");
        String sql = """
            SELECT p.product_id, p.name, p.category, p.price,
                   COALESCE(SUM(oi.quantity), 0) as total_sold,
                   COALESCE(SUM(oi.quantity * oi.unit_price), 0) as total_revenue
            FROM product p
            LEFT JOIN order_item oi ON p.product_id = oi.product_id
            GROUP BY p.product_id, p.name, p.category, p.price
            ORDER BY total_sold DESC
            LIMIT 10
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Monthly revenue report
    @GetMapping("/revenue/monthly")
    public List<Map<String, Object>> getMonthlyRevenue() {
        System.out.println("GET /api/reports/revenue/monthly called");
        String sql = """
            SELECT TO_CHAR(DATE_TRUNC('month', order_date), 'YYYY-MM') as month,
                   SUM(total_amount) as revenue,
                   COUNT(*) as order_count,
                   ROUND(AVG(total_amount), 2) as avg_order_value
            FROM orders
            GROUP BY DATE_TRUNC('month', order_date)
            ORDER BY month DESC
            LIMIT 12
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Daily revenue for current month
    @GetMapping("/revenue/daily")
    public List<Map<String, Object>> getDailyRevenue() {
        System.out.println("GET /api/reports/revenue/daily called");
        String sql = """
            SELECT DATE(order_date) as date,
                   SUM(total_amount) as revenue,
                   COUNT(*) as order_count
            FROM orders
            WHERE order_date >= DATE_TRUNC('month', CURRENT_DATE)
            GROUP BY DATE(order_date)
            ORDER BY date DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Revenue by category
    @GetMapping("/revenue/by-category")
    public List<Map<String, Object>> getRevenueByCategory() {
        System.out.println("GET /api/reports/revenue/by-category called");
        String sql = """
            SELECT c.name as category_name,
                   COUNT(DISTINCT oi.order_id) as order_count,
                   COALESCE(SUM(oi.quantity), 0) as items_sold,
                   COALESCE(SUM(oi.quantity * oi.unit_price), 0) as total_revenue
            FROM category c
            LEFT JOIN product p ON c.category_id = p.category_id
            LEFT JOIN order_item oi ON p.product_id = oi.product_id
            GROUP BY c.category_id, c.name
            ORDER BY total_revenue DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Top customers by spending
    @GetMapping("/top-customers")
    public List<Map<String, Object>> getTopCustomers() {
        System.out.println("GET /api/reports/top-customers called");
        String sql = """
            SELECT c.customer_id, c.full_name, c.email,
                   COUNT(o.order_id) as total_orders,
                   COALESCE(SUM(o.total_amount), 0) as total_spent,
                   ROUND(COALESCE(AVG(o.total_amount), 0), 2) as avg_order_value,
                   MAX(o.order_date) as last_order_date
            FROM customer c
            LEFT JOIN orders o ON c.customer_id = o.customer_id
            GROUP BY c.customer_id, c.full_name, c.email
            ORDER BY total_spent DESC
            LIMIT 10
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Customer lifetime value
    @GetMapping("/customer-lifetime-value")
    public List<Map<String, Object>> getCustomerLifetimeValue() {
        System.out.println("GET /api/reports/customer-lifetime-value called");
        String sql = """
            SELECT c.customer_id, c.full_name, c.email,
                   COUNT(DISTINCT o.order_id) as total_orders,
                   COUNT(DISTINCT b.booking_id) as total_bookings,
                   COALESCE(SUM(o.total_amount), 0) as order_revenue,
                   COALESCE(SUM(s.price), 0) as service_revenue,
                   COALESCE(SUM(o.total_amount), 0) + COALESCE(SUM(s.price), 0) as lifetime_value
            FROM customer c
            LEFT JOIN orders o ON c.customer_id = o.customer_id
            LEFT JOIN booking b ON c.customer_id = b.customer_id
            LEFT JOIN service s ON b.service_id = s.service_id
            GROUP BY c.customer_id, c.full_name, c.email
            ORDER BY lifetime_value DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Low stock products
    @GetMapping("/low-stock")
    public List<Map<String, Object>> getLowStockProducts() {
        System.out.println("GET /api/reports/low-stock called");
        String sql = """
            SELECT p.product_id, p.name, p.stock_quantity, 
                   c.name as category_name, v.name as vendor_name
            FROM product p
            LEFT JOIN category c ON p.category_id = c.category_id
            LEFT JOIN vendor v ON p.vendor_id = v.vendor_id
            WHERE p.stock_quantity < 10
            ORDER BY p.stock_quantity ASC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Inventory value report
    @GetMapping("/inventory-value")
    public List<Map<String, Object>> getInventoryValue() {
        System.out.println("GET /api/reports/inventory-value called");
        String sql = """
            SELECT c.name as category_name,
                   COUNT(p.product_id) as product_count,
                   SUM(p.stock_quantity) as total_units,
                   SUM(p.stock_quantity * p.price) as inventory_value
            FROM category c
            LEFT JOIN product p ON c.category_id = p.category_id
            GROUP BY c.category_id, c.name
            ORDER BY inventory_value DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Bookings by service
    @GetMapping("/bookings-by-service")
    public List<Map<String, Object>> getBookingsByService() {
        System.out.println("GET /api/reports/bookings-by-service called");
        String sql = """
            SELECT s.service_id, s.name as service_name, s.price,
                   COUNT(b.booking_id) as total_bookings,
                   COUNT(b.booking_id) * s.price as total_revenue
            FROM service s
            LEFT JOIN booking b ON s.service_id = b.service_id
            GROUP BY s.service_id, s.name, s.price
            ORDER BY total_bookings DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Employee performance
    @GetMapping("/employee-performance")
    public List<Map<String, Object>> getEmployeePerformance() {
        System.out.println("GET /api/reports/employee-performance called");
        String sql = """
            SELECT e.employee_id, e.full_name, e.role,
                   COUNT(DISTINCT o.order_id) as orders_processed,
                   COALESCE(SUM(o.total_amount), 0) as sales_amount,
                   COUNT(DISTINCT b.booking_id) as bookings_handled
            FROM employee e
            LEFT JOIN orders o ON e.employee_id = o.employee_id
            LEFT JOIN booking b ON e.employee_id = b.employee_id
            GROUP BY e.employee_id, e.full_name, e.role
            ORDER BY sales_amount DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Pets by species
    @GetMapping("/pets-by-species")
    public List<Map<String, Object>> getPetsBySpecies() {
        System.out.println("GET /api/reports/pets-by-species called");
        String sql = """
            SELECT species, 
                   COUNT(*) as count,
                   ROUND(AVG(age), 1) as avg_age
            FROM pet
            GROUP BY species
            ORDER BY count DESC
            """;
        return jdbcTemplate.queryForList(sql);
    }

    // Recent activity summary
    @GetMapping("/recent-activity")
    public Map<String, Object> getRecentActivity() {
        System.out.println("GET /api/reports/recent-activity called");
        String sql = """
            SELECT
                (SELECT COUNT(*) FROM orders WHERE order_date >= CURRENT_DATE - INTERVAL '7 days') as orders_last_week,
                (SELECT COUNT(*) FROM booking WHERE booking_date >= CURRENT_DATE - INTERVAL '7 days') as bookings_last_week,
                (SELECT COUNT(*) FROM customer WHERE customer_id IN (
                    SELECT DISTINCT customer_id FROM orders WHERE order_date >= CURRENT_DATE - INTERVAL '30 days'
                )) as active_customers_last_month,
                (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE order_date >= CURRENT_DATE - INTERVAL '7 days') as revenue_last_week
            """;
        return jdbcTemplate.queryForMap(sql);
    }
}