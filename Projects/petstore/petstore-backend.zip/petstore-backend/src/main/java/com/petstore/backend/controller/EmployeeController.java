package com.petstore.backend.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import com.petstore.backend.model.Employee;
import com.petstore.backend.repository.EmployeeRepository;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // GET all employees
    @GetMapping
    public List<Employee> getAllEmployees() {
        System.out.println("GET /api/employees called");
        return employeeRepository.findAll();
    }

    // GET employee by ID
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        System.out.println("GET /api/employees/" + id + " called");
        return employeeRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET employee with performance stats
    @GetMapping("/{id}/stats")
    public Map<String, Object> getEmployeeStats(@PathVariable Long id) {
        System.out.println("GET /api/employees/" + id + "/stats called");
        return jdbcTemplate.queryForMap("""
            SELECT e.*,
                   (SELECT COUNT(*) FROM orders o WHERE o.employee_id = e.employee_id) as total_orders,
                   (SELECT COALESCE(SUM(total_amount), 0) FROM orders o WHERE o.employee_id = e.employee_id) as total_sales,
                   (SELECT COUNT(*) FROM booking b WHERE b.employee_id = e.employee_id) as total_bookings
            FROM employee e
            WHERE e.employee_id = ?
            """, id);
    }

    // GET employees by role
    @GetMapping("/role/{role}")
    public List<Employee> getEmployeesByRole(@PathVariable String role) {
        System.out.println("GET /api/employees/role/" + role + " called");
        return jdbcTemplate.query(
            "SELECT * FROM employee WHERE role = ?",
            (rs, rowNum) -> {
                Employee e = new Employee();
                e.setEmployeeId(rs.getLong("employee_id"));
                e.setName(rs.getString("full_name"));
                e.setEmail(rs.getString("email"));
                e.setPhone(rs.getString("phone"));
                e.setHiringDate(rs.getDate("hire_date"));
                return e;
            },
            role
        );
    }

    // POST create employee
    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        System.out.println("POST /api/employees called");
        Employee saved = employeeRepository.save(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT update employee
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
        System.out.println("PUT /api/employees/" + id + " called");
        return employeeRepository.findById(id)
                .map(existing -> {
                    existing.setName(employeeDetails.getName());
                    existing.setEmail(employeeDetails.getEmail());
                    existing.setPhone(employeeDetails.getPhone());
                    return ResponseEntity.ok(employeeRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE employee
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        System.out.println("DELETE /api/employees/" + id + " called");
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}