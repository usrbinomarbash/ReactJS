package com.petstore.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/search")
@CrossOrigin(origins = "http://localhost:3000")
public class SearchController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Global search across all entities
    @GetMapping
    public Map<String, Object> globalSearch(@RequestParam String q) {
        System.out.println("GET /api/search?q=" + q + " called");
        String searchTerm = "%" + q.toLowerCase() + "%";

        List<Map<String, Object>> customers = jdbcTemplate.queryForList(
            "SELECT customer_id, full_name, email, 'customer' as type FROM customer WHERE LOWER(full_name) LIKE ? OR LOWER(email) LIKE ? LIMIT 5",
            searchTerm, searchTerm
        );

        List<Map<String, Object>> products = jdbcTemplate.queryForList(
            "SELECT product_id, name, category, price, 'product' as type FROM product WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ? LIMIT 5",
            searchTerm, searchTerm
        );

        List<Map<String, Object>> pets = jdbcTemplate.queryForList(
            "SELECT pet_id, name, species, breed, 'pet' as type FROM pet WHERE LOWER(name) LIKE ? OR LOWER(breed) LIKE ? LIMIT 5",
            searchTerm, searchTerm
        );

        List<Map<String, Object>> services = jdbcTemplate.queryForList(
            "SELECT service_id, name, price, 'service' as type FROM service WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ? LIMIT 5",
            searchTerm, searchTerm
        );

        return Map.of(
            "customers", customers,
            "products", products,
            "pets", pets,
            "services", services,
            "query", q
        );
    }

    // Advanced product search
    @GetMapping("/products")
    public List<Map<String, Object>> searchProducts(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) Boolean inStock,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortOrder) {
        
        System.out.println("GET /api/search/products called");
        
        StringBuilder sql = new StringBuilder("""
            SELECT p.*, c.name as category_name, v.name as vendor_name
            FROM product p
            LEFT JOIN category c ON p.category_id = c.category_id
            LEFT JOIN vendor v ON p.vendor_id = v.vendor_id
            WHERE 1=1
            """);

        if (name != null && !name.isEmpty()) {
            sql.append(" AND LOWER(p.name) LIKE '%").append(name.toLowerCase()).append("%'");
        }
        if (categoryId != null) {
            sql.append(" AND p.category_id = ").append(categoryId);
        }
        if (minPrice != null) {
            sql.append(" AND p.price >= ").append(minPrice);
        }
        if (maxPrice != null) {
            sql.append(" AND p.price <= ").append(maxPrice);
        }
        if (inStock != null && inStock) {
            sql.append(" AND p.stock_quantity > 0");
        }

        sql.append(" ORDER BY p.").append(sortBy).append(" ").append(sortOrder.toUpperCase());
        
        return jdbcTemplate.queryForList(sql.toString());
    }

    // Advanced customer search
    @GetMapping("/customers")
    public List<Map<String, Object>> searchCustomers(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) Boolean hasOrders,
            @RequestParam(required = false) Boolean hasPets) {
        
        System.out.println("GET /api/search/customers called");
        
        StringBuilder sql = new StringBuilder("""
            SELECT c.*,
                   (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.customer_id) as order_count,
                   (SELECT COUNT(*) FROM pet p WHERE p.customer_id = c.customer_id) as pet_count
            FROM customer c
            WHERE 1=1
            """);

        if (name != null && !name.isEmpty()) {
            sql.append(" AND LOWER(c.full_name) LIKE '%").append(name.toLowerCase()).append("%'");
        }
        if (email != null && !email.isEmpty()) {
            sql.append(" AND LOWER(c.email) LIKE '%").append(email.toLowerCase()).append("%'");
        }
        if (hasOrders != null && hasOrders) {
            sql.append(" AND EXISTS (SELECT 1 FROM orders o WHERE o.customer_id = c.customer_id)");
        }
        if (hasPets != null && hasPets) {
            sql.append(" AND EXISTS (SELECT 1 FROM pet p WHERE p.customer_id = c.customer_id)");
        }

        sql.append(" ORDER BY c.full_name");
        
        return jdbcTemplate.queryForList(sql.toString());
    }

    // Search orders by date range
    @GetMapping("/orders")
    public List<Map<String, Object>> searchOrders(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) String paymentMethod,
            @RequestParam(required = false) Double minAmount) {
        
        System.out.println("GET /api/search/orders called");
        
        StringBuilder sql = new StringBuilder("""
            SELECT o.*, c.full_name as customer_name, e.full_name as employee_name
            FROM orders o
            LEFT JOIN customer c ON o.customer_id = c.customer_id
            LEFT JOIN employee e ON o.employee_id = e.employee_id
            WHERE 1=1
            """);

        if (startDate != null) {
            sql.append(" AND o.order_date >= '").append(startDate).append("'");
        }
        if (endDate != null) {
            sql.append(" AND o.order_date <= '").append(endDate).append("'");
        }
        if (customerId != null) {
            sql.append(" AND o.customer_id = ").append(customerId);
        }
        if (paymentMethod != null && !paymentMethod.isEmpty()) {
            sql.append(" AND o.payment_method = '").append(paymentMethod).append("'");
        }
        if (minAmount != null) {
            sql.append(" AND o.total_amount >= ").append(minAmount);
        }

        sql.append(" ORDER BY o.order_date DESC");
        
        return jdbcTemplate.queryForList(sql.toString());
    }

    // Search bookings
    @GetMapping("/bookings")
    public List<Map<String, Object>> searchBookings(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) Long serviceId,
            @RequestParam(required = false) String status) {
        
        System.out.println("GET /api/search/bookings called");
        
        StringBuilder sql = new StringBuilder("""
            SELECT b.*, c.full_name as customer_name, p.name as pet_name, 
                   s.name as service_name, e.full_name as employee_name
            FROM booking b
            LEFT JOIN customer c ON b.customer_id = c.customer_id
            LEFT JOIN pet p ON b.pet_id = p.pet_id
            LEFT JOIN service s ON b.service_id = s.service_id
            LEFT JOIN employee e ON b.employee_id = e.employee_id
            WHERE 1=1
            """);

        if (startDate != null) {
            sql.append(" AND b.booking_date >= '").append(startDate).append("'");
        }
        if (endDate != null) {
            sql.append(" AND b.booking_date <= '").append(endDate).append("'");
        }
        if (customerId != null) {
            sql.append(" AND b.customer_id = ").append(customerId);
        }
        if (serviceId != null) {
            sql.append(" AND b.service_id = ").append(serviceId);
        }
        if (status != null && !status.isEmpty()) {
            sql.append(" AND b.status = '").append(status).append("'");
        }

        sql.append(" ORDER BY b.booking_date DESC");
        
        return jdbcTemplate.queryForList(sql.toString());
    }
}