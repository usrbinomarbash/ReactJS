package com.petstore.backend.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import com.petstore.backend.model.Service;
import com.petstore.backend.repository.ServiceRepository;

@RestController
@RequestMapping("/api/services")
@CrossOrigin(origins = "http://localhost:3000")
public class ServiceController {

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // GET all services
    @GetMapping
    public List<Service> getAllServices() {
        System.out.println("GET /api/services called");
        return serviceRepository.findAll();
    }

    // GET service by ID
    @GetMapping("/{id}")
    public ResponseEntity<Service> getServiceById(@PathVariable Long id) {
        System.out.println("GET /api/services/" + id + " called");
        return serviceRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET service with booking stats
    @GetMapping("/{id}/stats")
    public Map<String, Object> getServiceStats(@PathVariable Long id) {
        System.out.println("GET /api/services/" + id + "/stats called");
        return jdbcTemplate.queryForMap("""
            SELECT s.*,
                   COUNT(b.booking_id) as total_bookings,
                   COUNT(b.booking_id) * s.price as total_revenue
            FROM service s
            LEFT JOIN booking b ON s.service_id = b.service_id
            WHERE s.service_id = ?
            GROUP BY s.service_id
            """, id);
    }

    // GET popular services
    @GetMapping("/popular")
    public List<Map<String, Object>> getPopularServices() {
        System.out.println("GET /api/services/popular called");
        return jdbcTemplate.queryForList("""
            SELECT s.*, COUNT(b.booking_id) as booking_count
            FROM service s
            LEFT JOIN booking b ON s.service_id = b.service_id
            GROUP BY s.service_id
            ORDER BY booking_count DESC
            LIMIT 5
            """);
    }

    // POST create service
    @PostMapping
    public ResponseEntity<Service> createService(@RequestBody Service service) {
        System.out.println("POST /api/services called");
        Service saved = serviceRepository.save(service);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT update service
    @PutMapping("/{id}")
    public ResponseEntity<Service> updateService(@PathVariable Long id, @RequestBody Service serviceDetails) {
        System.out.println("PUT /api/services/" + id + " called");
        return serviceRepository.findById(id)
                .map(existing -> {
                    existing.setName(serviceDetails.getName());
                    existing.setDuration(serviceDetails.getDescription());
                    existing.setPrice(serviceDetails.getPrice());
                    existing.setDuration(serviceDetails.getDurationMin());
                    return ResponseEntity.ok(serviceRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE service
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteService(@PathVariable Long id) {
        System.out.println("DELETE /api/services/" + id + " called");
        if (serviceRepository.existsById(id)) {
            serviceRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}