# Backend 

- How to Add A pet
- Used the postmapping annotation within the controller 


```java
//any change you make remember
mvn clean compile
```

```java
//run
mvn spring-boot:run
```

- Each table in the database should have a class named after it in the model directory
- Where you will store each entity in the database is called a repository
- Each table you want to have information stored should have its repository in the repository in the respository directory
- Service holds all the bussiness logic of the application and must have its own directory
- Every java class is mapped directly to the table in the database using the annotations
- The repository directory is the bridge between the java code and the database


## Timeline

##### November 3rd 2025

- Able to add a pet on the front end and it appears in the table
- When I query the database it appears
- When i hit remove on the frontend it is popped from the table 


